<?php

namespace App\Controllers;

class Home extends BaseController
{

    protected $angkatan;
    protected $jurusan;
    protected $user;
    protected $siswa;
    protected $tempat;
    protected $application;
    protected $pembimbing;
    protected $logbooks;
    protected $pengumuman;
    protected $nilai;
    protected $dosen_pembimbing;

    public function __construct()
    {
        $this->angkatan     = new \App\Models\AngkatanModel();
        $this->jurusan      = new \App\Models\JurusanModel();
        $this->user         = new \App\Models\UserModel();
        $this->siswa        = new \App\Models\SiswaModel();
        $this->tempat       = new \App\Models\TempatModel();
        $this->application  = new \App\Models\ApplicationModel();
        $this->pembimbing   = new \App\Models\PembimbingModel();
        $this->logbooks     = new \App\Models\LogBookModel();
        $this->pengumuman   = new \App\Models\PengumumanModel();
        $this->nilai        = new \App\Models\NilaiModel();
        $this->dosen_pembimbing = new \App\Models\DosenPembimbingModel();
    }

    public function index()
    {
        $pengumuman = $this->pengumuman->select("pengumuman.*, CASE WHEN auth_groups.name = 'admin' THEN 'Admin' ELSE COALESCE(pembimbing.nama, dosen_pembimbing.nama, users.username) END as pembimbing")
            ->join('users', 'users.id = pengumuman.oleh')
            ->join('pembimbing', 'pembimbing.user_id = users.id', 'left')
            ->join('dosen_pembimbing', 'dosen_pembimbing.user_id = users.id', 'left')
            ->join('auth_groups_users', 'auth_groups_users.user_id = users.id', 'left')
            ->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id', 'left')
            ->orderBy('pengumuman.created_at', "DESC")
            ->groupBy('pengumuman.id')
            ->findAll();

        $is_safety_ready = false;
        $my_application = null;
        $catatan_dosen = 0;
        if (in_groups('siswa')) {
            $sid = getSidByUid(user_id());
            if ($sid) {
                $catatan_dosen = $this->logbooks->where('id_siswa', $sid)
                    ->where('catatan_dosen !=', null)
                    ->where('catatan_dosen !=', '')
                    ->where('is_read_dosen', 0)
                    ->countAllResults();
            }

            $siswa_data = $this->siswa->where('user_id', user_id())->first();
            if ($siswa_data) {
                $is_safety_ready = (bool)$siswa_data->is_safety_ready;
                
                // Get personal application status
                $my_application = $this->application->select('lamaran.*, tempat_magang.nama as instansi, tempat_magang.alamat')
                    ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
                    ->where('lamaran.id_siswa', $siswa_data->id)
                    ->orderBy('lamaran.created_at', 'DESC')
                    ->first();
            }
        }

        return view('dashboard', [
            "title"         => "Magang | Dashboard",
            "page_title"    => in_groups('admin') ? 'Dashboard Admin' : (in_groups('pembimbing') ? 'Dashboard Pembimbing' : (in_groups('dosen_pembimbing') ? 'Dashboard Dosen Pembimbing' : 'Dashboard Siswa')),
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => in_groups('admin') ? ['Dashboard', 'Admin'] : (in_groups('pembimbing') ? ['Dashboard', 'Pembimbing'] : (in_groups('dosen_pembimbing') ? ['Dashboard', 'Dosen Pembimbing'] : ['Dashboard', user()->username])),
            "total_siswa"   => $this->user->join('auth_groups_users', 'auth_groups_users.user_id = users.id')->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id')->where('auth_groups.name', 'siswa')->countAllResults(),
            "total_tempat"  => $this->tempat->countAllResults(),
            "tempat_buka"   => $this->tempat->where("status", 'buka')->countAllResults(),
            "tempat_tutup"  => $this->tempat->where("status", 'tutup')->countAllResults(),
            "pengumuman"    => $pengumuman,
            "catatan_dosen" => $catatan_dosen,
            "is_safety_ready" => $is_safety_ready,
            "my_application" => $my_application
        ]);
    }

    public function profile()
    {
        return view('profile', [
            "title"         => "Magang | Profile",
            "page_title"    => in_groups('admin') ? 'Profile Admin' : (in_groups('pembimbing') ? 'Profile Pembimbing' : (in_groups('dosen_pembimbing') ? 'Profile Dosen Pembimbing' : 'Profile Siswa')),
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => in_groups('admin') ? ['Profile', 'Admin'] : (in_groups('pembimbing') ? ['Profile', 'Pembimbing'] : (in_groups('dosen_pembimbing') ? ['Profile', 'Dosen Pembimbing'] : ['Profile', user()->username])),
            "jurusan"       => $this->jurusan->findAll(),
            "angkatan"      => $this->angkatan->findAll(),
        ]);
    }

    public function tempat()
    {
        // Server-Side Auto Sync: Paksa sinkronisasi sekali per sesi login mahasiswa
        $syncKey = 'synced_' . (user_id() ?? 'guest');
        if (in_groups('siswa') && !session()->get($syncKey)) {
            session()->set($syncKey, true);
            return redirect()->to(current_url());
        }

        $tempat = $this->tempat->select('tempat_magang.*, pembimbing.nama as pembimbing')
            ->join('pembimbing', 'pembimbing.id = tempat_magang.pid')
            ->orderBy('tempat_magang.status', "ASC")
            ->findAll();

        return view('tempat', [
            "title"         => "Magang | Tempat Magang",
            "page_title"    => "Daftar Divisi Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Divisi Magang'],
            "tempat"        => $tempat
        ]);
    }

    public function nilai()
    {
        // siswa and angkatan
        $dataSiswa = $this->siswa->select('siswa.*, angkatan.nama as angkatan, angkatan.tahun, angkatan.tgl_selesai')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', 'left')
            ->where('siswa.id', getSidByUid(user_id()))
            ->first();

        return view('nilai', [
            "title"         => "Magang | Nilai Siswa",
            "page_title"    => "Nilai Magang Siswa",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Nilai'],
            "nilai"         => $this->nilai->where('ids', getSidByUid(user_id()))->first(),
            "siswa"         => $dataSiswa
        ]);
    }

    public function daftarHadir($id = null)
    {
        $tempat = $this->application->select('lamaran.id_siswa as sid, tempat_magang.nama as instansi, tempat_magang.id as tid, tempat_magang.pid, tempat_magang.alamat, tempat_magang.hp, tempat_magang.email')
            ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
            ->where('lamaran.id_siswa', getSidByUid(user_id()))
            ->orderBy('lamaran.created_at', "DESC")
            ->first();

        $is_safety_ready = false;
        if (in_groups('siswa')) {
            $siswa_data = $this->siswa->where('user_id', user_id())->first();
            if ($siswa_data) {
                $is_safety_ready = (bool)$siswa_data->is_safety_ready;
            }
        }

        $data = [
            "title"         => "Magang | Daftar Hadir Siswa",
            "page_title"    => "Daftar Hadir Siswa Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Daftar Hadir', user()->username],
            "tempat"        => $tempat,
            "logbooks"      => $this->logbooks->select('*')->select("IF(DATE(created_at) > tanggal, true, false) as telat", false)->where('id_siswa', getSidByUid(user_id()))->findAll(),
            "is_safety_ready" => $is_safety_ready
        ];

        if ($id && is_numeric($id)) {
            $edit_logbook = $this->logbooks->select('*')->select("IF(DATE(created_at) > tanggal, true, false) as telat", false)->where('id_siswa', getSidByUid(user_id()))->where('id', $id)->first();

            if ($edit_logbook->status !== 'rejected') {
                return redirect()->to('/kehadiran');
            }

            $data['edit_logbook'] = $edit_logbook;
        }

        return view('kehadiran', $data);
    }

    public function logbookku()
    {
        $sid = getSidByUid(user_id());
        $this->logbooks->where('id_siswa', $sid)->where('catatan_dosen !=', null)->set(['is_read_dosen' => 1])->update();

        $data = [
            "title"         => "Magang | Logbook Saya",
            "page_title"    => "Daftar Kegiatan Logbook",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Laporan Logbook', user()->username],
            "logbooks"      => $this->logbooks->select('*')->select("IF(DATE(created_at) > tanggal, true, false) as telat", false)->where('id_siswa', $sid)->orderBy('tanggal', 'DESC')->findAll()
        ];
        return view('logbookku', $data);
    }

    public function application()
    {
        $data = [
            "title"         => "Magang | Application Siswa",
            "page_title"    => "Lamaran Siswa Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Application', user()->username]
        ];

        if (in_groups('admin')) {
            $data['applications'] = $this->application->select('lamaran.*, siswa.nama, siswa.nim, siswa.kelas, siswa.no_hp, siswa.laporan, siswa.alamat, angkatan.tahun, angkatan.nama as angkatan, angkatan.tgl_selesai, dosen_pembimbing.nama as nama_dosen')
                ->join('siswa', 'siswa.id = lamaran.id_siswa')
                ->join('angkatan', 'angkatan.id = siswa.angkatan')
                ->join('dosen_pembimbing', 'dosen_pembimbing.id = lamaran.id_dosen_pembimbing', 'left')
                ->orderBy('lamaran.created_at', "DESC")
                ->findAll();
            
            $data['kelas'] = $this->siswa->select('kelas')->groupBy('kelas')->orderBy('kelas', 'ASC')->findAll();
            $data['angkatan'] = $this->angkatan->findAll();
            $data['dosen'] = $this->dosen_pembimbing->findAll();
        } elseif (in_groups('siswa')) {
            $data['applications'] = $this->application->select('lamaran.*, siswa.nama, siswa.nim, siswa.laporan, angkatan.tahun, angkatan.nama as angkatan, angkatan.tgl_selesai, tempat_magang.nama as instansi, tempat_magang.alamat, pembimbing.nama as nama_pembimbing, pembimbing.no_hp as hp_pembimbing, pembimbing.email as email_pembimbing, dosen_pembimbing.nama as nama_dosen, dosen_pembimbing.no_hp as hp_dosen, dosen_pembimbing.email as email_dosen')
                ->join('siswa', 'siswa.id = lamaran.id_siswa')
                ->join('angkatan', 'angkatan.id = siswa.angkatan')
                ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
                ->join('pembimbing', 'pembimbing.id = tempat_magang.pid')
                ->join('dosen_pembimbing', 'dosen_pembimbing.id = lamaran.id_dosen_pembimbing', 'left')
                ->where('lamaran.id_siswa', getSidByUid(user_id()))
                ->orderBy('lamaran.created_at', "DESC")
                ->findAll();
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('application', $data);
    }

    public function logbooks($idt)
    {
        $idt = (int) $idt;
        $tempat = $this->tempat->find($idt);
        if (!$tempat) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Tempat magang tidak ditemukan.');
        }
        $siswas = $this->application->select('lamaran.*, siswa.id as sid, siswa.nama, siswa.nim, siswa.kelas, siswa.no_hp, siswa.alamat, angkatan.tahun')
            ->join('siswa', 'siswa.id = lamaran.id_siswa')
            ->join('angkatan', 'angkatan.id = siswa.angkatan')
            ->where(['lamaran.id_tempat' => $idt])
            ->whereIn('lamaran.status', ['accepted', 'selesai'])
            ->orderBy('lamaran.created_at', "DESC")
            ->findAll();

        return view('logbook', [
            "title"         => "Magang | logbook Siswa",
            "page_title"    => "logbook Siswa Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['logbook', user()->username, $tempat->nama],
            "siswas"         => $siswas,
            "idt"           => $idt,
        ]);
    }

    public function logbook_siswa($idt, $nim)
    {
        $idt = (int) $idt;
        $tempat = $this->tempat->find($idt);
        if (!$tempat) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Tempat magang tidak ditemukan.');
        }

        $siswa = $this->siswa
            ->select('siswa.*, angkatan.nama as angkatan, angkatan.tahun, angkatan.tgl_selesai')
            ->join('angkatan', 'angkatan.id = siswa.angkatan')
            ->where('nim', $nim)
            ->first();

        if (!$siswa) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Siswa tidak ditemukan.');
        }

        $siswas = $this->application->select('lamaran.*, siswa.id as sid, siswa.nama, siswa.nim, siswa.kelas, siswa.no_hp, siswa.alamat, siswa.laporan, angkatan.tahun, angkatan.nama as angkatan')
            ->join('siswa', 'siswa.id = lamaran.id_siswa')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', 'left')
            ->where(['lamaran.id_tempat' => $idt])
            ->whereIn('lamaran.status', ['accepted', 'selesai', 'pending'])
            ->orderBy('lamaran.created_at', "DESC")
            ->findAll();

        $log = $this->logbooks->select("*")
            ->select("IF(DATE(created_at) > tanggal, true, false) as telat", false)
            ->where([
                'id_siswa' => $siswa->id, 
                'id_pembimbing' => $tempat->pid
            ])
            ->orderBy('tanggal', 'DESC')
            ->findAll();

        return view('logbook_siswa', [
            "title"         => "Magang | logbook Siswa",
            "page_title"    => "logbook Siswa Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['logbook', user()->username, $tempat->nama, $nim],
            "selected"      => $siswa,
            "siswas"        => $siswas,
            "siswa"         => $siswa,
            "idt"           => $idt,
            "logbooks"      => $log
        ]);
    }

    public function man_tempat()
    {
        $tempat = $this->tempat->select('tempat_magang.*, pembimbing.nama as pembimbing')
            ->join('pembimbing', 'pembimbing.id = tempat_magang.pid', 'left')
            ->findAll();
        $pem = $this->pembimbing->findAll();
        $pem = array_map(function ($p) {
            return [
                'value' => $p->nama,
                'label' => $p->nama,
                'num'   => $p->id,
            ];
        }, $pem);

        return view('man_tempat', [
            "title"             => "Magang | Manajemen Tempat",
            "page_title"        => "Manajemen Divisi Magang",
            "segment"           => $this->request->getUri()->getSegments(),
            "breadcrumb"        => ['Manajemen', 'Tempat'],
            "tempat"            => $tempat,
            "pembimbing"        => $this->pembimbing->findAll(),
            "pembimbing_json"   => json_encode($pem)
        ]);
    }

    public function tempat_edit($id)
    {
        return view('edit_tempat', [
            'title'         => 'Magang | Edit Tempat Magang',
            'page_title'    => 'Edit Tempat Magang',
            'segment'       => $this->request->getUri()->getSegments(),
            'breadcrumb'    => ['Manajemen', 'Tempat', 'Edit'],
            'tempat'        => $this->tempat->find($id),
            'pembimbing'    => $this->pembimbing->findAll()
        ]);
    }

    public function man_pembimbing()
    {
        return $this->man_user('pembimbing');
    }

    public function man_dosen()
    {
        return $this->man_user('dosen_pembimbing');
    }

    public function man_user($type = 'pembimbing')
    {
        $duser = $this->user
            ->select('users.id, users.username, users.email')
            ->select('pembimbing.id as pid, pembimbing.nama as p_nama, pembimbing.no_hp as p_hp, pembimbing.foto as p_foto')
            ->select('dosen_pembimbing.id as did, dosen_pembimbing.nama as d_nama, dosen_pembimbing.no_hp as d_hp, dosen_pembimbing.nidn, dosen_pembimbing.foto as d_foto')
            ->join('pembimbing', 'pembimbing.user_id = users.id', 'left')
            ->join('dosen_pembimbing', 'dosen_pembimbing.user_id = users.id', 'left')
            ->groupStart();

        if ($type === 'dosen_pembimbing') {
            $duser = $duser->where('dosen_pembimbing.id IS NOT NULL');
            $title = "Magang | Manajemen Dosen";
            $page_title = "Manajemen Data Dosen Pembimbing";
            $breadcrumb = ['Manajemen', 'Dosen Pembimbing'];
            $role_filter = 'dosen_pembimbing';
        } else {
            $duser = $duser->where('pembimbing.id IS NOT NULL');
            $title = "Magang | Manajemen Pembimbing";
            $page_title = "Manajemen Data Pembimbing Lapangan & Admin";
            $breadcrumb = ['Manajemen', 'Pembimbing Lapangan'];
            $role_filter = 'pembimbing';
        }
            
        $duser = $duser->groupEnd()->findAll();

        foreach($duser as $u) {
            $u->nama = $u->p_nama ?? $u->d_nama;
            $u->no_hp = $u->p_hp ?? $u->d_hp;
            $u->nidn = $u->nidn ?? '';
            $u->foto = $u->p_foto ?? $u->d_foto;
        }

        return view('man_user', [
            "title"         => $title,
            "page_title"    => $page_title,
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => $breadcrumb,
            "user"          => $duser,
            "role_type"     => $role_filter
        ]);
    }

    public function man_siswa()
    {
        $dsiswa = $this->user
            ->select('users.id, users.username, users.email, siswa.nim, siswa.nama, siswa.kelas, siswa.jurusan, siswa.instansi, siswa.no_hp, siswa.alamat, siswa.foto, angkatan.nama as angkatan, angkatan.tahun')
            ->join('auth_groups_users', 'auth_groups_users.user_id = users.id')
            ->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id')
            ->join('siswa', 'siswa.user_id = users.id', 'left')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', "left")
            ->where('auth_groups.name', 'siswa')
            ->findAll();

        $angkatan_jeson = $this->angkatan->findAll();
        $angkatan_jeson = array_map(function ($item) {
            return [
                'value' => $item->nama . ' - ' . $item->tahun,
                'label' => $item->nama . ' - ' . $item->tahun,
                'no'    => $item->id,
                'tahun' => $item->tahun,
            ];
        }, $angkatan_jeson);

        return view('man_siswa', [
            "title"         => "Magang | Manajemen Siswa",
            "page_title"    => "Manajemen Data Siswa",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Manajemen', 'Siswa'],
            "angkatan"      => $this->angkatan->findAll(),
            "jurusan"       => $this->jurusan->findAll(),
            "siswa"         => $dsiswa,
            "angkatan_json" => json_encode($angkatan_jeson)
        ]);
    }

    public function siswa_edit($nim)
    {
        $dsiswa = $this->user
            ->select('users.id, users.username, users.email, siswa.nim, siswa.nama, siswa.kelas, siswa.jurusan, siswa.instansi, siswa.no_hp, siswa.alamat, siswa.foto, angkatan.nama as angkatan, angkatan.tahun, angkatan.id as num')
            ->join('siswa', 'siswa.user_id = users.id', 'left')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', "left")
            ->where('siswa.nim', $nim)
            ->first();

        $angkatan_jeson = $this->angkatan->findAll();
        $angkatan_jeson = array_map(function ($item) {
            return [
                'value' => $item->nama . ' - ' . $item->tahun,
                'label' => $item->nama . ' - ' . $item->tahun,
                'no'    => $item->id,
                'tahun' => $item->tahun,
            ];
        }, $angkatan_jeson);

        return view('siswa_edit', [
            "title"         => "Magang | Edit Data siswa",
            "page_title"    => "Edit Data Siswa $nim",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Siswa', 'Edit', $nim],
            "siswa"         => $dsiswa,
            "angkatan"      => $this->angkatan->findAll(),
            "jurusan"       => $this->jurusan->findAll(),
            "angkatan_json" => json_encode($angkatan_jeson)
        ]);
    }

    public function laporan()
    {
        // Ambil data jurusan unik langsung dari tabel siswa agar admin tidak perlu input master data jurusan lagi
        $jurusan = $this->siswa->select('jurusan')
            ->where('jurusan !=', null)
            ->where('jurusan !=', '')
            ->groupBy('jurusan')
            ->orderBy('jurusan', 'ASC')
            ->findAll();

        return view('laporan_all', [
            "title"         => "Magang | Laporan",
            "page_title"    => "Laporan",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Laporan'],
            "jurusan"       => $jurusan,
            "angkatan"      => $this->angkatan->orderBy('tahun', 'DESC')->findAll(),
            "tahun"         => $this->angkatan->orderBy('tahun', 'DESC')->groupBy('tahun')->findAll(),
        ]);
    }

    public function laporan_akhir()
    {
        $uid = user_id();
        $sid = getSidByUid($uid);
        
        $db = \Config\Database::connect();
        $application = $db->table('lamaran')
            ->select('lamaran.*, tempat_magang.nama as instansi, pembimbing.nama as nama_pembimbing, dosen_pembimbing.nama as nama_dosen')
            ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat', 'left')
            ->join('pembimbing', 'pembimbing.id = tempat_magang.pid', 'left')
            ->join('dosen_pembimbing', 'dosen_pembimbing.id = lamaran.id_dosen_pembimbing', 'left')
            ->where('lamaran.id_siswa', $sid)
            ->where('lamaran.status !=', 'rejected')
            ->get()->getRow();

        return view('laporan_akhir', [
            "title"         => "Magang | Laporan Akhir",
            "page_title"    => "Laporan Akhir Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Kegiatanku', 'Laporan Akhir'],
            "application"   => $application,
            "siswa"         => $this->siswa->find($sid)
        ]);
    }

    public function laporan_all()
    {
        return view('laporan_all', [
            "title"         => "Magang | Site Settings",
            "page_title"    => "Pengaturan",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Settings'],
            "jurusan"       => $this->jurusan->orderBy('nama_jurusan', 'ASC')->findAll(),
            "angkatan"      => $this->angkatan->orderBy('tahun', 'DESC')->findAll(),
            "tahun"         => $this->angkatan->orderBy('tahun', 'DESC')->groupBy('tahun')->findAll(),
        ]);
    }

    public function settings()
    {
        return view('settings', [
            "title"         => "Magang | Site Settings",
            "page_title"    => "Pengaturan",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Settings'],
            "angkatan"      => $this->angkatan->orderBy('tahun', 'DESC')->findAll(),
            "jurusan"       => $this->jurusan->findAll()
        ]);
    }

    public function bimbingan_dosen()
    {
        // Mengambil data dosen pembimbing berdasarkan user yang sedang login
        $dosen = $this->dosen_pembimbing->where('user_id', user_id())->first();

        if (!$dosen) {
            return redirect()->back()->with('error', 'Data Dosen Pembimbing tidak ditemukan.');
        }

        $applications = $this->application->select('lamaran.*, siswa.nama, siswa.nim, siswa.kelas, siswa.no_hp, siswa.laporan, siswa.id as sid, siswa.is_laporan_approved, tempat_magang.nama as instansi')
            ->join('siswa', 'siswa.id = lamaran.id_siswa')
            ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat', 'left')
            ->where('lamaran.id_dosen_pembimbing', $dosen->id)
            ->orderBy('lamaran.created_at', 'DESC')
            ->findAll();

        return view('bimbingan_dosen', [
            "title"         => "Magang | Mahasiswa Bimbingan",
            "page_title"    => "Daftar Mahasiswa Bimbingan",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Bimbingan', 'Dosen Pembimbing'],
            "applications"  => $applications
        ]);
    }

    public function logbook_bimbingan_dosen($nim)
    {
        $siswa = $this->siswa
            ->select('siswa.*, angkatan.nama as angkatan, angkatan.tahun, angkatan.tgl_selesai')
            ->join('angkatan', 'angkatan.id = siswa.angkatan')
            ->where('nim', $nim)
            ->first();

        if (!$siswa) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $log = $this->logbooks->select("*")->select("IF(DATE(created_at) > tanggal, true, false) as telat", false)->where(['id_siswa' => $siswa->id])->findAll();

        return view('logbook_dosen_siswa', [
            "title"         => "Magang | Logbook Siswa",
            "page_title"    => "Logbook Siswa Magang",
            "segment"       => $this->request->getUri()->getSegments(),
            "breadcrumb"    => ['Bimbingan', 'Dosen Pembimbing', $nim],
            "siswa"         => $siswa,
            "logbooks"      => $log
        ]);
    }
}
