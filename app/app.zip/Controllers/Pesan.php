<?php

namespace App\Controllers;

use App\Models\PesanModel;
use App\Models\SiswaModel;
use App\Models\PembimbingModel;
use App\Models\DosenPembimbingModel;
use App\Models\ApplicationModel;

class Pesan extends BaseController
{
    protected PesanModel $pesanModel;

    public function __construct()
    {
        $this->pesanModel = new PesanModel();
    }

    /**
     * Main chat page - shows conversation list and optionally opens a chat
     */
    public function index(?int $partnerId = null)
    {
        if (!logged_in()) return redirect()->to('/login');

        $userId    = user_id();
        $userRoles = user()->getRoles();

        // Build list of people current user can chat with
        $contacts  = $this->getContacts($userId, $userRoles);
        $chatList  = $this->pesanModel->getConversationList($userId);
        $unread    = $this->pesanModel->countUnread($userId);

        $conversation = [];
        $partner      = null;

        if ($partnerId) {
            // Mark as read
            $this->pesanModel->markAsRead($partnerId, $userId);
            $conversation = $this->pesanModel->getConversation($userId, $partnerId);
            $partner      = $this->getPartnerInfo($partnerId);
        }

        return view('pesan', [
            'title'        => 'Pesan',
            'page_title'   => 'Pesan',
            'breadcrumb'   => ['Beranda' => '/', 'Pesan' => '/pesan'],
            'segment'      => ['pesan'],
            'contacts'     => $contacts,
            'chatList'     => $chatList,
            'conversation' => $conversation,
            'partner'      => $partner,
            'partner_id'   => $partnerId,
            'unread'       => $unread,
            'user_id'      => $userId,
        ]);
    }

    /**
     * Send a message via AJAX
     */
    public function send()
    {
        if (!logged_in()) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized']);
        }

        $senderId   = user_id();
        $receiverId = (int) $this->request->getPost('receiver_id');
        $pesan      = trim($this->request->getPost('pesan'));

        if (!$receiverId || empty($pesan)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Data tidak lengkap']);
        }

        // Validate that sender is allowed to message receiver
        if (!$this->canMessage($senderId, $receiverId)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Tidak diizinkan mengirim pesan ke pengguna ini']);
        }

        $saved = $this->pesanModel->insert([
            'sender_id'   => $senderId,
            'receiver_id' => $receiverId,
            'pesan'       => $pesan,
            'is_read'     => 0,
        ]);

        if ($saved) {
            // Send email notification async (fire and forget)
            $this->sendEmailNotification($senderId, $receiverId, $pesan);

            $msg = $this->pesanModel->find($this->pesanModel->getInsertID());
            return $this->response->setJSON([
                'success'    => true,
                'message'    => 'Pesan terkirim',
                'id'         => $msg->id,
                'pesan'      => $pesan,
                'created_at' => $msg->created_at,
                'sender_id'  => $senderId,
                'csrf_hash'  => csrf_hash(), // Return new hash
            ]);
        }

        return $this->response->setJSON(['success' => false, 'message' => 'Gagal mengirim pesan']);
    }

    /**
     * Poll for new messages (AJAX long polling / short poll)
     */
    public function poll(int $partnerId)
    {
        if (!logged_in()) {
            return $this->response->setJSON([]);
        }

        $userId    = user_id();
        $lastId    = (int) $this->request->getGet('last_id');

        // Mark as read first
        $this->pesanModel->markAsRead($partnerId, $userId);

        $newMessages = $this->pesanModel->db->table('pesan')
            ->select('pesan.*, su.username as sender_username')
            ->join('users su', 'su.id = pesan.sender_id', 'left')
            ->groupStart()
                ->where('pesan.sender_id', $partnerId)
                ->where('pesan.receiver_id', $userId)
            ->groupEnd()
            ->orGroupStart()
                ->where('pesan.sender_id', $userId)
                ->where('pesan.receiver_id', $partnerId)
            ->groupEnd()
            ->where('pesan.id >', $lastId)
            ->orderBy('pesan.created_at', 'ASC')
            ->get()->getResult();

        $unread = $this->pesanModel->countUnread($userId);

        return $this->response->setJSON([
            'messages' => $newMessages,
            'unread'   => $unread,
        ]);
    }

    /**
     * Get unread count (for navbar badge update)
     */
    public function unread()
    {
        if (!logged_in()) return $this->response->setJSON(['count' => 0]);
        return $this->response->setJSON(['count' => $this->pesanModel->countUnread(user_id())]);
    }

    // ----------------------------------------------------------------
    // Private helpers
    // ----------------------------------------------------------------

    /**
     * Determine which contacts the current user can send messages to.
     */
    private function getContacts(int $userId, array $roles): array
    {
        $contacts = [];
        $db       = \Config\Database::connect();

        // Admin is always available for everyone to message
        if (!in_array('admin', $roles)) {
            $admins = $db->table('users')
                ->select('users.id as user_id, users.username as nama, "Admin" as role')
                ->join('auth_groups_users', 'auth_groups_users.user_id = users.id')
                ->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id')
                ->where('auth_groups.name', 'admin')
                ->get()->getResult();
            
            foreach ($admins as $admin) {
                $contacts[] = [
                    'user_id' => $admin->user_id,
                    'nama'    => 'Administrator (' . $admin->nama . ')',
                    'role'    => 'Admin',
                    'foto'    => null,
                ];
            }
        }

        if (in_array('siswa', $roles)) {
            // Student can message their assigned pembimbing lapangan and dosen pembimbing
            $appModel  = new ApplicationModel();
            $accepted  = $appModel->where('id_siswa', (new SiswaModel())->where('user_id', $userId)->first()?->id ?? 0)
                                  ->whereIn('status', ['accepted', 'selesai'])
                                  ->first();

            if ($accepted) {
                // Pembimbing lapangan
                $tempat = $db->table('tempat_magang')->where('id', $accepted->id_tempat)->get()->getRow();
                if ($tempat && $tempat->pid) {
                    $p = $db->table('pembimbing')
                            ->join('users', 'users.id = pembimbing.user_id')
                            ->where('pembimbing.id', $tempat->pid)
                            ->get()->getRow();
                    if ($p) {
                        $contacts[] = [
                            'user_id' => $p->user_id,
                            'nama'    => $p->nama,
                            'role'    => 'Pembimbing Lapangan',
                            'foto'    => $p->foto ?? null,
                        ];
                    }
                }

                // Dosen pembimbing
                if (isset($accepted->id_dosen_pembimbing) && $accepted->id_dosen_pembimbing) {
                    $d = $db->table('dosen_pembimbing')
                            ->join('users', 'users.id = dosen_pembimbing.user_id')
                            ->where('dosen_pembimbing.id', $accepted->id_dosen_pembimbing)
                            ->get()->getRow();
                    if ($d) {
                        $contacts[] = [
                            'user_id' => $d->user_id,
                            'nama'    => $d->nama,
                            'role'    => 'Dosen Pembimbing',
                            'foto'    => $d->foto ?? null,
                        ];
                    }
                }
            }
        }

        if (in_array('admin', $roles)) {
            // Admin can message any student or mentor
            $students = $db->table('siswa')->select('user_id, nama, foto')->get()->getResult();
            foreach ($students as $s) {
                $contacts[] = ['user_id' => $s->user_id, 'nama' => $s->nama, 'role' => 'Siswa', 'foto' => $s->foto];
            }
            $pembimbing = $db->table('pembimbing')->select('user_id, nama, foto')->get()->getResult();
            foreach ($pembimbing as $p) {
                $contacts[] = ['user_id' => $p->user_id, 'nama' => $p->nama, 'role' => 'Pembimbing Lapangan', 'foto' => $p->foto];
            }
            $dosen = $db->table('dosen_pembimbing')->select('user_id, nama, foto')->get()->getResult();
            foreach ($dosen as $d) {
                $contacts[] = ['user_id' => $d->user_id, 'nama' => $d->nama, 'role' => 'Dosen Pembimbing', 'foto' => $d->foto];
            }
        }

        if (in_array('pembimbing', $roles)) {
            // Field supervisor: students in their division + dosen pembimbing of those students
            $pembimbing = $db->table('pembimbing')->where('user_id', $userId)->get()->getRow();
            if ($pembimbing) {
                // Students
                $students = $db->table('lamaran')
                    ->select('lamaran.id_siswa, siswa.user_id as s_uid, siswa.nama, siswa.foto')
                    ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
                    ->join('siswa', 'siswa.id = lamaran.id_siswa')
                    ->where('tempat_magang.pid', $pembimbing->id)
                    ->whereIn('lamaran.status', ['accepted', 'selesai'])
                    ->get()->getResult();

                foreach ($students as $s) {
                    $contacts[] = [
                        'user_id' => $s->s_uid,
                        'nama'    => $s->nama,
                        'role'    => 'Siswa',
                        'foto'    => $s->foto ?? null,
                    ];
                    // Their dosen pembimbing
                    $lamaran = $db->table('lamaran')
                        ->where('id_siswa', $s->id_siswa)
                        ->whereIn('status', ['accepted', 'selesai'])
                        ->get()->getRow();
                    if ($lamaran && isset($lamaran->id_dosen_pembimbing) && $lamaran->id_dosen_pembimbing) {
                        $d = $db->table('dosen_pembimbing')
                                ->join('users', 'users.id = dosen_pembimbing.user_id')
                                ->where('dosen_pembimbing.id', $lamaran->id_dosen_pembimbing)
                                ->get()->getRow();
                        if ($d) {
                            $exists = array_filter($contacts, fn($c) => $c['user_id'] === (int)$d->user_id);
                            if (empty($exists)) {
                                $contacts[] = [
                                    'user_id' => (int)$d->user_id,
                                    'nama'    => $d->nama,
                                    'role'    => 'Dosen Pembimbing',
                                    'foto'    => $d->foto ?? null,
                                ];
                            }
                        }
                    }
                }
            }
        }

        if (in_array('dosen_pembimbing', $roles)) {
            // Academic supervisor: their students + field supervisors of those students
            $dosen = $db->table('dosen_pembimbing')->where('user_id', $userId)->get()->getRow();
            if ($dosen) {
                $lamarans = $db->table('lamaran')
                    ->select('lamaran.*, siswa.user_id as s_uid, siswa.nama as s_nama, siswa.foto as s_foto, 
                              tempat_magang.pid,
                              pembimbing.user_id as p_uid, pembimbing.nama as p_nama, pembimbing.foto as p_foto')
                    ->join('siswa', 'siswa.id = lamaran.id_siswa')
                    ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat', 'left')
                    ->join('pembimbing', 'pembimbing.id = tempat_magang.pid', 'left')
                    ->where('lamaran.id_dosen_pembimbing', $dosen->id)
                    ->whereIn('lamaran.status', ['accepted', 'selesai'])
                    ->get()->getResult();

                foreach ($lamarans as $l) {
                    // Student
                    $exists = array_filter($contacts, fn($c) => $c['user_id'] === (int)$l->s_uid);
                    if (empty($exists)) {
                        $contacts[] = [
                            'user_id' => (int)$l->s_uid,
                            'nama'    => $l->s_nama,
                            'role'    => 'Siswa',
                            'foto'    => $l->s_foto ?? null,
                        ];
                    }
                    // Field supervisor
                    if ($l->p_uid) {
                        $pExists = array_filter($contacts, fn($c) => $c['user_id'] === (int)$l->p_uid);
                        if (empty($pExists)) {
                            $contacts[] = [
                                'user_id' => (int)$l->p_uid,
                                'nama'    => $l->p_nama,
                                'role'    => 'Pembimbing Lapangan',
                                'foto'    => $l->p_foto ?? null,
                            ];
                        }
                    }
                }
            }
        }

        return $contacts;
    }

    /**
     * Verify that sender is allowed to message receiver
     */
    private function canMessage(int $senderId, int $receiverId): bool
    {
        $senderRoles   = user()->getRoles();
        $db            = \Config\Database::connect();

        // Get receiver roles
        $receiverRoles = $db->table('auth_groups_users')
            ->select('auth_groups.name')
            ->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id')
            ->where('user_id', $receiverId)
            ->get()->getResult();
        $receiverRoles = array_map(fn($r) => $r->name, $receiverRoles);

        // Admin can message anyone
        if (in_array('admin', $senderRoles)) return true;

        // Anyone can message an admin
        if (in_array('admin', $receiverRoles)) return true;

        // Siswa -> pembimbing or dosen_pembimbing (must be assigned)
        if (in_array('siswa', $senderRoles) && (in_array('pembimbing', $receiverRoles) || in_array('dosen_pembimbing', $receiverRoles))) {
            $contacts = $this->getContacts($senderId, $senderRoles);
            return !empty(array_filter($contacts, fn($c) => (int)$c['user_id'] === (int)$receiverId));
        }

        // Pembimbing -> siswa or dosen_pembimbing
        if (in_array('pembimbing', $senderRoles) && (in_array('siswa', $receiverRoles) || in_array('dosen_pembimbing', $receiverRoles))) {
            $contacts = $this->getContacts($senderId, $senderRoles);
            return !empty(array_filter($contacts, fn($c) => (int)$c['user_id'] === (int)$receiverId));
        }

        // Dosen pembimbing -> siswa or pembimbing
        if (in_array('dosen_pembimbing', $senderRoles) && (in_array('siswa', $receiverRoles) || in_array('pembimbing', $receiverRoles))) {
            $contacts = $this->getContacts($senderId, $senderRoles);
            return !empty(array_filter($contacts, fn($c) => (int)$c['user_id'] === (int)$receiverId));
        }

        return false;
    }

    /**
     * Get partner display info
     */
    private function getPartnerInfo(int $partnerId): ?object
    {
        $db = \Config\Database::connect();

        $user = $db->table('users')
            ->select('users.id, users.username, users.email,
                COALESCE(s.nama, p.nama, d.nama) as nama,
                COALESCE(s.foto, p.foto, d.foto) as foto,
                (SELECT GROUP_CONCAT(ag.name SEPARATOR ",") 
                 FROM auth_groups_users agu JOIN auth_groups ag ON ag.id = agu.group_id 
                 WHERE agu.user_id = users.id) as roles')
            ->join('siswa s', 's.user_id = users.id', 'left')
            ->join('pembimbing p', 'p.user_id = users.id', 'left')
            ->join('dosen_pembimbing d', 'd.user_id = users.id', 'left')
            ->where('users.id', $partnerId)
            ->get()->getRow();

        return $user;
    }

    /**
     * Send Gmail notification to receiver
     */
    private function sendEmailNotification(int $senderId, int $receiverId, string $pesan): void
    {
        try {
            $db           = \Config\Database::connect();
            $senderUser   = $db->table('users')
                ->select('users.email, COALESCE(s.nama, p.nama, d.nama) as nama')
                ->join('siswa s', 's.user_id = users.id', 'left')
                ->join('pembimbing p', 'p.user_id = users.id', 'left')
                ->join('dosen_pembimbing d', 'd.user_id = users.id', 'left')
                ->where('users.id', $senderId)
                ->get()->getRow();

            $receiverUser = $db->table('users')
                ->where('id', $receiverId)
                ->get()->getRow();

            if (!$receiverUser || empty($receiverUser->email)) return;

            $senderNama  = $senderUser->nama ?? 'Pengguna';
            $appUrl      = base_url('/pesan/' . $senderId);
            $shortPesan  = mb_strlen($pesan) > 100 ? mb_substr($pesan, 0, 100) . '...' : $pesan;

            $emailBody = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f9f9; padding: 20px;'>
                <div style='background: #1a1a2e; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;'>
                    <h2 style='color: #fff; margin: 0;'>SIMAGANG PLN ASAME</h2>
                    <p style='color: #aaa; margin: 5px 0 0;'>Sistem Informasi Magang</p>
                </div>
                <div style='background: #fff; padding: 30px; border-radius: 0 0 8px 8px;'>
                    <h3 style='color: #333;'>Pesan Baru dari {$senderNama}</h3>
                    <div style='background: #f0f4ff; border-left: 4px solid #3b82f6; padding: 15px; border-radius: 4px; margin: 20px 0;'>
                        <p style='margin: 0; color: #555; font-style: italic;'>\"{$shortPesan}\"</p>
                    </div>
                    <p style='color: #666;'>Klik tombol di bawah untuk membaca dan membalas pesan.</p>
                    <div style='text-align: center; margin: 25px 0;'>
                        <a href='{$appUrl}' 
                           style='background: #3b82f6; color: white; padding: 12px 28px; border-radius: 6px; text-decoration: none; font-weight: bold; display: inline-block;'>
                           Buka Pesan
                        </a>
                    </div>
                    <p style='color: #999; font-size: 12px; text-align: center; margin-top: 20px;'>
                        Email ini dikirim otomatis oleh Sistem SIMAGANG. Jangan balas email ini.
                    </p>
                </div>
            </div>";

            $emailService = \Config\Services::email();
            $emailService->setFrom(
                env('SMTP_USER', 'simagang@maxinide.com'),
                'SIMAGANG PLN ASAME'
            );
            $emailService->setTo($receiverUser->email);
            $emailService->setSubject("Pesan Baru dari {$senderNama} - SIMAGANG");
            $emailService->setMailType('html');
            $emailService->setMessage($emailBody);
            $emailService->send(false);
        } catch (\Throwable $e) {
            // Silent fail - don't break the send flow
            log_message('error', 'Email notification failed: ' . $e->getMessage());
        }
    }
}
