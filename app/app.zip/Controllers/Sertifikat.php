<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use Dompdf\Options;

class Sertifikat extends BaseController
{
    public function download($sid)
    {
        // Must be logged in and either the student themselves or an admin
        if (!in_groups('admin') && getSidByUid(user_id()) != $sid) {
            return redirect()->to('/')->with('error', 'Anda tidak memiliki akses ke sertifikat ini.');
        }

        $siswaModel = new \App\Models\SiswaModel();
        $nilaiModel = new \App\Models\NilaiModel();
        $lamaranModel = new \App\Models\ApplicationModel();

        $siswa = $siswaModel->select('siswa.*, angkatan.tahun')->join('angkatan', 'angkatan.id = siswa.angkatan')->where('siswa.id', $sid)->first();
        if (!$siswa) {
            return redirect()->back()->with('error', 'Siswa tidak ditemukan.');
        }

        $lamaran = $lamaranModel->select('lamaran.*, tempat_magang.nama as tempat')
                                ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
                                ->where('id_siswa', $sid)
                                ->where('lamaran.status', 'selesai')
                                ->first();
        
        // Wait, if it's finished, maybe it's still 'accepted' and just the date has passed?
        if (!$lamaran) {
            $lamaran = $lamaranModel->select('lamaran.*, tempat_magang.nama as tempat')
                                ->join('tempat_magang', 'tempat_magang.id = lamaran.id_tempat')
                                ->where('id_siswa', $sid)
                                ->where('lamaran.status', 'accepted')
                                ->first();
        }

        if (!$lamaran) {
            return redirect()->back()->with('error', 'Siswa belum memiliki divisi magang atau status magang belum selesai.');
        }

        // NEW: Workflow Checklist
        if (!$siswa->is_safety_ready) {
            return redirect()->back()->with('error', 'Sertifikat tidak dapat diterbitkan: Siswa belum mengonfirmasi Materi Safety & K3.');
        }

        if (!$siswa->is_laporan_approved) {
            return redirect()->back()->with('error', 'Sertifikat tidak dapat diterbitkan: Laporan akhir belum disetujui oleh pembimbing.');
        }

        $nilai = $nilaiModel->where('ids', $sid)->first();

        if (!$nilai) {
            return redirect()->back()->with('error', 'Nilai belum diinput lengkap.');
        }

        // Hitung rata-rata: Normalisasi nilai pembimbing (skala 10) ke skala 100
        $items_pembimbing = [
            $nilai->n_disiplin, $nilai->n_motivasi, $nilai->n_kehadiran, 
            $nilai->n_kreatifitas, $nilai->n_kejujuran, $nilai->n_kesopanan, 
            $nilai->n_kerjasama, $nilai->n_laporan
        ];
        
        $total_pembimbing = 0;
        foreach ($items_pembimbing as $ni) {
            // Jika nilai <= 10, asumsikan skala 1-10 dan konversi ke skala 100
            $total_pembimbing += ($ni <= 10) ? ($ni * 10) : $ni;
        }

        $total_nilai = $total_pembimbing;
        $pembagi = 8;

        if (isset($nilai->n_dosen) && $nilai->n_dosen !== null) {
            $total_nilai += $nilai->n_dosen;
            $pembagi++;
        }
        $rata = round($total_nilai / $pembagi, 2);

        $grade = "Sangat Baik";
        if ($rata < 85 && $rata >= 75) $grade = "Baik";
        elseif ($rata < 75 && $rata >= 60) $grade = "Cukup";
        elseif ($rata < 60) $grade = "Kurang";

        $data = [
            'siswa' => $siswa,
            'lamaran' => $lamaran,
            'nilai' => $nilai,
            'rata' => $rata,
            'grade' => $grade
        ];

        try {
            $html = view('sertifikat/template', $data);

            $options = new Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);

            $dompdf = new Dompdf($options);
            $dompdf->setPaper('A4', 'landscape');
            $dompdf->loadHtml($html);
            $dompdf->render();

            $dompdf->stream("Sertifikat_Magang_{$siswa->nim}_{$siswa->nama}.pdf", ["Attachment" => true]);
            exit;
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal membuat PDF: ' . $e->getMessage());
        }
    }
}
