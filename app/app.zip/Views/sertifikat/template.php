<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sertifikat Magang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff;
            text-align: center;
        }
        .container {
            width: 95%;
            height: 90%;
            margin: auto;
            border: 15px solid #2b4b72;
            padding: 20px;
            position: relative;
        }
        .header {
            margin-top: 30px;
            font-size: 40px;
            font-weight: bold;
            color: #2b4b72;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .subheader {
            font-size: 20px;
            color: #555;
            margin-bottom: 40px;
        }
        .content {
            font-size: 20px;
            margin: 20px 0;
            line-height: 1.5;
        }
        .name {
            font-size: 35px;
            font-weight: bold;
            color: #d9534f;
            text-decoration: underline;
            margin: 20px 0;
        }
        .kampus {
            font-size: 25px;
            font-weight: bold;
            color: #333;
        }
        .footer {
            margin-top: 60px;
            font-size: 18px;
            text-align: right;
            padding-right: 50px;
        }
        .signature {
            margin-top: 50px;
            border-top: 1px solid #333;
            width: 250px;
            display: inline-block;
            text-align: center;
            font-weight: bold;
            padding-top: 10px;
        }
        .logo {
            width: 100px;
            position: absolute;
            top: 40px;
            left: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Logo can be dynamic, using a base64 encoded image or an absolute local path if allowed -->
        <div class="header">Sertifikat Kelulusan Magang</div>
        <div class="subheader">Diberikan Sebagai Penghargaan Kepada:</div>
        
        <div class="name"><?= strtoupper($siswa->nama) ?></div>
        <div class="content">
            Nomor Induk Mahasiswa (NIM) : <?= $siswa->nim ?><br>
            Telah menyelesaikan program Praktek Kerja Lapangan (Magang) <br>
            di instansi <strong><?= $lamaran->tempat ?></strong><br>
            Untuk Tahun Ajaran <?= $siswa->tahun ?>. <br><br>
            Dengan Capaian Rata-Rata Nilai Akhir: <br>
            <strong style="font-size: 26px; color:#2b4b72;"><?= $rata ?> (Predikat: <?= $grade ?>)</strong>
        </div>

        <div class="footer">
            Diterbitkan pada: <?= date('d F Y') ?><br><br><br><br>
            <div class="signature">Admin Sistem Magang</div>
        </div>
    </div>
</body>
</html>
