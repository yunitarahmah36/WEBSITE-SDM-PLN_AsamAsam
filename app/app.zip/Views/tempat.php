<?= $this->extend('main'); ?>
<?= $this->section('content'); ?>

<!-- filter -->
<div class="mb-4 card card-body ">
    <h6>Filter Divisi Magang</h6>
    <div class="row">
        <div class="col-12 col-sm-5 col-md-4">
            <div class="nav-wrapper position-relative end-0">
                <ul class="nav nav-pills nav-fill p-1" role="tablist" id="filterStatus">
                    <li class="nav-item">
                        <a class="nav-link mb-0 px-0 py-1 text-success active" data-bs-toggle="tab" href="javascript:void(0);" data-status="buka" role="tab" aria-controls="preview" aria-selected="true">
                            <span class="material-icons align-middle mb-1 me-1">
                                done
                            </span>
                            Buka
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mb-0 px-0 py-1 text-danger" data-bs-toggle="tab" href="javascript:void(0);" data-status="tutup" role="tab" aria-controls="code" aria-selected="false">
                            <span class="material-icons align-middle mb-1 me-1">
                                close
                            </span>
                            Tutup
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="col-12 col-sm-7 col-md-8">
            <div class="input-group input-group-outline">
                <input type="text" class="form-control" placeholder="Cari divisi magang" aria-label="Cari divisi magang" aria-describedby="button-addon2" id="search">
            </div>
        </div>
    </div>
</div>

<div class="row mb-5 row-instansi" data-masonry='{"percentPosition": true }'>
    <?php foreach ($tempat as $t) : ?>
        <?php
        if (filter_var($t->foto, FILTER_VALIDATE_URL)) {
            $foto = $t->foto;
        } else {
            $foto = '/assets/img/tempat_magang/' . $t->foto;
        }
        ?>
        <div class="col-12 col-sm-6 col-md-4 col-xxl-3 mb-4 cardInstansi <?= strtolower($t->status) ?>">
            <div class="card mt-4" data-animation="<?= initCheck(user_id(), $t->id) && $t->status == 'buka'  ? 'true' : 'false' ?>">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <a class="d-block blur-shadow-image">
                        <img src="<?= $foto ?>" alt="img-blur-shadow" height="200px" class="img-fluid shadow border-radius-lg">
                    </a>
                    <div class="colored-shadow" style="background-image: url(&quot;<?= $foto ?>&quot;);"></div>
                </div>
                <div class="card-body text-center">
                    <div class="<?= initCheck(user_id(), $t->id) ? 'mt-n6' : 'mt-n4' ?> mx-auto">
                        <?php 
                        $sid = getSidByUid(user_id());
                        $allApps = getApplicationSiswa($sid);
                        $isPending = false;
                        $isAccepted = false;
                        
                        foreach($allApps as $ap) {
                            if($ap->status == 'pending') $isPending = true;
                            if(in_array($ap->status, ['accepted', 'selesai'])) $isAccepted = true;
                        }
                        ?>

                        <?php if (initCheck(user_id(), $t->id)) : ?>
                            <button type="button" class="btn bg-gradient-primary btn-sm mb-0 me-2 btn-daftar" data-instansi="<?= $t->nama ?>" data-tid="<?= $t->id ?>" <?= $t->status == 'tutup' || getSlotAvailable($t->id) == 0 ? 'disabled' : '' ?>>Daftar</button>
                        <?php else : ?>
                            <?php if ($isAccepted) : ?>
                                <span class="badge badge-success shadow">Sudah Terdaftar</span>
                            <?php elseif ($isPending) : ?>
                                <span class="badge bg-gradient-info shadow">Menunggu Persetujuan</span>
                            <?php elseif (getSlotAvailable($t->id) == 0) : ?>
                                <span class="badge badge-warning shadow">Kuota Penuh</span>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                    <h6 class="font-weight-normal mt-4"><?= $t->nama ?></h6>
                    <p class="mb-0"><?= $t->deskripsi ?></p>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer d-flex justify-content-between align-items-center">
                    <div class="text-sm font-weight-normal my-auto" title="kuota siswa magang" data-bs-toggle="tooltip"><i class="fa fa-id-badge pe-1"></i> <?= getSlotAvailable($t->id) ?></div>
                    <div class="text-sm my-auto" title="pembimbing magang" data-bs-toggle="tooltip"><?= $t->pembimbing ?></div>
                    <div class="badge badge-sm <?= getSlotAvailable($t->id) == 0 ? 'badge-warning' : ($t->status == 'buka' ? 'badge-success' : 'badge-danger') ?>"><?= getSlotAvailable($t->id) == 0 ? 'FULL' : $t->status ?></div>
                </div>
            </div>
        </div>
    <?php endforeach ?>
</div>
<?= $this->endSection(); ?>

<?= $this->section('bottomsc'); ?>
<!-- Load SweetAlert Early -->
<script src="/assets/js/plugins/sweetalert.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/masonry-layout@4.2.2/dist/masonry.pkgd.min.js"></script>

<script>
    // Daftarkan event click sesegera mungkin menggunakan delegasi
    $(document).on('click', '.btn-daftar', function() {
        var instansi = $(this).data('instansi');
        var tid = $(this).data('tid');
        
        // Ambil token CSRF terbaru langsung dari meta tag saat tombol diklik
        var csrfName = '<?= config('App')->CSRFTokenName ?>';
        var csrfHeader = '<?= config('App')->CSRFHeaderName ?>';
        var csrfHash = $('meta[name="' + csrfName + '"]').attr('content');

        Swal.fire({
            title: 'Daftar Magang',
            text: "Apakah anda yakin ingin mendaftar magang di " + instansi + "?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Daftar',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '/tempat/daftar',
                    type: 'post',
                    headers: { [csrfHeader]: csrfHash },
                    data: { tid: tid },
                    success: function(data) {
                        if (data.success) {
                            Swal.fire({
                                title: 'Berhasil',
                                text: data.message || ("Anda berhasil mendaftar magang di " + instansi),
                                icon: 'success'
                            }).then(() => { window.location.href = '/application'; });
                        } else {
                            Swal.fire({ title: 'Gagal', text: data.message || "Terjadi kesalahan.", icon: 'error' });
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            title: 'Sesi Berakhir',
                            text: "Sesi Anda mungkin telah kedaluwarsa atau terjadi gangguan koneksi. Silakan reload halaman ini.",
                            icon: 'warning'
                        });
                    }
                })
            }
        })
    });

    $(document).ready(function() {
        var $grid = $('.row-instansi').masonry({
            itemSelector: '.cardInstansi',
            percentPosition: true
        });

        // Tunggu gambar dimuat sebelum memicu layouting
        $grid.imagesLoaded().progress( function() {
            $grid.masonry('layout');
        });

        var status = 'buka';
        sh(status);

        $('#search').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $('.cardInstansi').each(function() {
                var text = $(this).text().toLowerCase();
                if (text.indexOf(value) > -1 && ($(this).hasClass(status) || status == 'semua')) {
                    $(this).show().removeClass('d-none');
                } else {
                    $(this).hide().addClass('d-none');
                }
            });
            $grid.masonry('layout');
        });

        $('#filterStatus a').on('click', function(e) {
            e.preventDefault();
            status = $(this).data('status');
            sh(status);
        });

        function sh(status) {
            $('.cardInstansi').each(function() {
                if ($(this).hasClass(status) || status == 'semua') {
                    $(this).show().removeClass('d-none');
                } else {
                    $(this).hide().addClass('d-none');
                }
            });
            $grid.masonry('layout');
        }
    })
</script>
<script src="https://unpkg.com/imagesloaded@5/imagesloaded.pkgd.min.js"></script>
<?= $this->endSection(); ?>