<?= $this->extend('main'); ?>
<?= $this->section('content'); ?>
<div class="row mb-5">
    <div class="col-12">
        <div class="card">
            <div class="card-header pb-0">
                <span class="h5">Edit Data Siswa</span><br>
                Edit data siswa magang
            </div>
            <div class="card-body">
                <form role="form text-left" id="fesiswa" enctype="multipart/form-data">
                    <input type="hidden" name="items" value="<?= $siswa->id ?>">
                    <input type="hidden" name="old_email" value="<?= $siswa->email ?>">
                    <div class="row">
                        <div class="col-6">
                            <div class="input-group input-group-outline mb-3 is-filled" data-bs-toggle="tooltip" title="NIM Tidak dapat diedit" data-container="body" data-animation="true">
                                <label for="nim" class="form-label">NIM</label>
                                <input type="text" readonly name="nim" id="nim" class="form-control" value="<?= $siswa->nim ?>" readonly required>
                            </div>
                            <div class="input-group input-group-outline mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" id="email" class="form-control" value="<?= $siswa->email ?>" required>
                            </div>
                            <div class="input-group input-group-outline mb-3">
                                <label for="hp" class="form-label">Nomor Hp/Wa</label>
                                <input type="number" name="hp" id="hp" class="form-control" value="<?= $siswa->no_hp ?>" required>
                            </div>
                            <div class="input-group input-group-outline mb-3">
                                <label for="password" class="form-label">Password (Biarkan kosong jika tidak diubah)</label>
                                <input type="password" name="password" id="password" class="form-control" autocomplete="new-password">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="input-group input-group-outline mb-3">
                                <label for="nama" class="form-label">Nama</label>
                                <input type="text" name="nama" id="nama" class="form-control" value="<?= $siswa->nama ?>" required>
                            </div>
                            <div class="input-group input-group-outline mb-3 is-filled">
                                <label for="kelas" class="form-label">Kelas</label>
                                <input type="text" name="kelas" id="kelas" class="form-control" value="<?= $siswa->kelas ?>" required>
                            </div>

                            <input type="hidden" name="angkatan" id="angval" value="<?= $siswa->num ?>">

                            <div class="input-group input-group-outline mb-3">
                                <label for="angkatan" class="form-label">Gelombang / Angkatan</label>
                                <input type="text" name="autoang" id="angkatan" class="form-control" value="<?= $siswa->angkatan . " - " . $siswa->tahun ?>" required>
                            </div>
                        </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="input-group input-group-outline mb-3 <?= !empty($siswa->jurusan) ? 'is-filled' : '' ?>">
                                            <label for="jurusan" class="form-label">Jurusan</label>
                                            <input type="text" name="jurusan" id="jurusan" class="form-control" value="<?= $siswa->jurusan ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-group input-group-outline mb-3 <?= !empty($siswa->instansi) ? 'is-filled' : '' ?>">
                                            <label for="instansi" class="form-label">Nama Instansi (Asal Sekolah/PT)</label>
                                            <input type="text" name="instansi" id="instansi" class="form-control" value="<?= $siswa->instansi ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group input-group-outline mb-3 <?= !empty($siswa->alamat) ? 'is-filled' : '' ?>">
                                    <textarea name="alamat" id="alamat" rows="2" class="form-control" placeholder="Alamat Lengkap" required><?= $siswa->alamat ?></textarea>
                                </div>
                                <div class="input-group input-group-outline mb-3">
                                    <input type="file" name="foto" id="foto" class="form-control" accept="image/*">
                                </div>
                                <small class="text-xs text-secondary mt-n2 mb-3 d-block">Biarkan kosong jika tidak ingin mengubah foto profil.</small>
                            </div>
                        </div>
                    <div class="text-center gap-3 d-flex align-items-center justify-content-end mt-4">
                        <a href="/man/siswa" class="btn btn-round bg-gradient-light">Batal</a>
                        <button type="submit" class="btn btn-round bg-gradient-dark" required>Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>


<?= $this->section('topsc'); ?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<?= $this->endSection(); ?>


<?= $this->section('bottomsc'); ?>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script src="/assets/js/plugins/datatables.js"></script>
<script src="/assets/js/plugins/sweetalert.min.js"></script>

<script>
    $(document).ready(function() {
        const BASE_URL = "<?= base_url() ?>";
        const angkatan_json = JSON.parse('<?= $angkatan_json ?>');

        $('#fesiswa #kelas').on('change', function() {
            if ($(this).val() != "") {
                $(this).parent().addClass('is-filled');
            } else {
                $(this).parent().removeClass('is-filled');
            }
        });

        $("#angkatan").autocomplete({
            source: angkatan_json,
            autoFocus: true,
            select: function(event, ui) {
                $('#fesiswa #angval').val(ui.item.no);

            },
        });

        $("#fesiswa").on('submit', function(s) {
            s.preventDefault(), 
            $.ajax({
                url: "/siswa/update",
                type: "post",
                data: new FormData(this),
                dataType: "json",
                contentType: false,
                processData: false,
                success: function(s) {
                    s.success ? Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: s.message,
                        showConfirmButton: !1,
                        timer: 1500
                    }).then(s => {
                        window.location.href = '/man/siswa'
                    }) : Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: s.message,
                        showConfirmButton: !0
                    });
                }
            });
        })
    });
</script>
<?= $this->endSection(); ?>