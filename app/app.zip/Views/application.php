<?= $this->extend('main'); ?>
<?= $this->section('topsc'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .select2-container .select2-selection--single {
            height: 38px !important;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 38px !important;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px !important;
        }

        .select2-container {
            width: 100% !important;
            z-index: 9999 !important;
        }
    </style>
<?= $this->endSection(); ?>

<?= $this->section('content'); ?>



<div class="row">
    <div class="col-12">
        <div class="card card-body py-3 px-4">
            <?php if (in_groups('admin') || in_groups('pembimbing')) : ?>
                <div class="d-flex justify-content-between align-items-center px-2">
                    <div>
                        <span class="h5 mb-0 pb-0">Daftar Pendaftaran Siswa</span> <br>
                        Daftar berikut merupakan Lamaran siswa yang telah mendaftar di tempat magang.
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-6 col-md-4">
                        <div class="input-group input-group-outline mb-3">
                            <label for="filstatus" class="form-label">Status</label>
                            <select name="filstatus" id="filstatus" class="form-control">
                                <option value=""></option>
                                <option value="accepted">Accepted</option>
                                <option value="selesai">Finished</option>
                                <option value="unfinish">Unfinish</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="input-group input-group-outline mb-3">
                            <label for="filjurusan" class="form-label">Kelas</label>
                            <select name="filjurusan" id="filjurusan" class="form-control">
                                <option value=""></option>
                                <?php foreach ($kelas as $k) : ?>
                                    <option value="<?= $k->kelas ?>"><?= $k->kelas ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="input-group input-group-outline mb-3">
                            <label for="filangkatan" class="form-label">Angkatan</label>
                            <select name="filangkatan" id="filangkatan" class="form-control">
                                <option value=""></option>
                                <?php foreach ($angkatan as $a) : ?>
                                    <option value="<?= $a->nama ?>">XI <?= $a->nama ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="input-group input-group-outline mb-3">
                            <label for="fillaporan" class="form-label">Laporan</label>
                            <select name="fillaporan" id="fillaporan" class="form-control">
                                <option value=""></option>
                                <option value="lihat">Sudah</option>
                                <option value="belum">Belum</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="input-group input-group-outline mb-3">
                            <label for="filsearch" class="form-label">Cari Data</label>
                            <input type="text" name="filsearch" id="filsearch" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover table-stripped" id="tbapplications">
                        <thead>
                            <tr>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">NIM</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Kelas</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Angkatan</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Instansi</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Dosen Pembimbing</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Laporan</th>
                                <th class="ps-3 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1 ?>
                            <?php foreach ($applications as $application) : ?>
                                <?php $instansi = $application->id_tempat == null ? $application->custom_tempat : getNamaInstansi($application->id_tempat) ?>
                                <tr>
                                    <td class="ps-3 text-xs font-weight-bold"><?= $no++ ?></td>
                                    <td class="ps-3 text-xs font-weight-bold">
                                        <?php if ($application->laporan == null && (date('Y-m-d') > $application->tgl_selesai)) : ?>
                                            <span class="badge badge-warning border border-warning">unfinish</span>
                                        <?php else : ?>
                                            <?= genBadgeStatusApplication($application->status) ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="ps-3 text-xs font-weight-bold">
                                        <div class="badge badge-secondary"><?= $application->nim ?></div>
                                    </td>
                                    <td class="ps-3 text-xs font-weight-bold"><?= $application->kelas ?></td>
                                    <td class="ps-3 text-xs font-weight-bold"><?= $application->nama ?></td>
                                    <td class="ps-3 text-xs font-weight-bold"><?= $application->angkatan ?></td>
                                    <td class="ps-3 text-xs font-weight-bold"><?= isVerifiedInstansi($application->id_tempat) ?><span class="iname"><?= $instansi ?></span></td>
                                    <td class="ps-3 text-xs font-weight-bold"><?= $application->nama_dosen ?: '<span class="text-secondary opacity-6">Belum ada</span>' ?></td>
                                    <td class="ps-3 text-xs font-weight-bold">
                                        <?php if ($application->laporan) : ?>
                                            <a href="/assets/laporan/<?= $application->laporan ?>" target="_blank" class="badge badge-info border border-info">LIHAT</a>
                                        <?php else : ?>
                                            <a href="#" class="badge badge-dark border border-dark" style="cursor: not-allowed !important; pointer-events: all !important;">BELUM</a>
                                        <?php endif ?>
                                    </td>
                                    <td class="ps-3 text-xs font-weight-bold">
                                        <button <?= $application->status != 'pending' ? 'disabled style="opacity: 0.6;"' : '' ?> class="badge border border-1 border-danger text-danger btn-destroy" title="Hapus data" data-item="<?= $application->id; ?>"><i class="fas fa-trash"></i></button>
                                        <button <?= $application->status == 'reject by system' ? 'disabled style="opacity: 0.6;"' : '' ?> class="badge border border-1 border-warning text-warning btn-edit-status" title="Update Status" data-stts="<?= $application->status ?>" data-item="<?= $application->id; ?>" data-dosen="<?= $application->id_dosen_pembimbing ?>"><i class="fas fa-tag"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>

                <!-- Modal Edit Pendaftaran -->
                <div class="modal fade" id="modalEditApplication" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Update Pendaftaran</h5>
                            </div>
                            <form id="formEditApplication">
                                <div class="modal-body">
                                    <input type="hidden" name="item" id="edit_app_id">
                                    
                                    <div class="input-group input-group-outline mb-3 is-filled">
                                        <label for="edit_status" class="form-label">Status</label>
                                        <select name="status" id="edit_status" class="form-control">
                                            <option value="pending">Pending</option>
                                            <option value="accepted">Accepted</option>
                                            <option value="selesai">Finished</option>
                                            <option value="unfinish">Unfinished</option>
                                        </select>
                                    </div>

                                    <?php if (in_groups('admin')) : ?>
                                    <div class="input-group input-group-outline mb-3 is-filled">
                                        <label for="edit_dosen" class="form-label">Dosen Pembimbing</label>
                                        <select name="id_dosen_pembimbing" id="edit_dosen" class="form-control">
                                            <option value="">-- Belum Ditentukan --</option>
                                            <?php foreach ($dosen as $d) : ?>
                                                <option value="<?= $d->id ?>"><?= $d->nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <div class="d-flex justify-content-between align-items-center px-2 mb-4">
                    <div>
                        <span class="h5 mb-0 pb-0">Status pendaftaran anda</span> <br>
                        daftar berikut merupakan status pendaftaran anda di tempat magang.
                    </div>
                    <a class="btn btn-sm btn-dark" href="/tempat">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>

                <div>
                    <?php foreach ($applications as $app) : ?>
                        <div class="card card-body rounded bg-gray-200 p-2 px-4 mb-3 liInstansi">
                            <div class="d-flex justify-content-between align-items-center">
                                <div data-bs-toggle="tooltip" data-bs-placement="top" title="<?= $app->created_at ?>" data-container="body" data-animation="true">
                                    <div class="h6 mb-0 pb-0"><?= $app->instansi ?></div>
                                    <div class="text-xs"><?= $app->alamat ?></div>
                                </div>
                                <div style="text-align: end !important;">
                                    <div class="mb-2">
                                        <?php if ($app->laporan == null && (date('Y-m-d') > $app->tgl_selesai)) : ?>
                                            <span class="badge badge-warning border border-warning">unfinish</span>
                                        <?php else : ?>
                                            <?= genBadgeStatusApplication($app->status) ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-xs"><?= $app->updated_at ?></div>
                                </div>
                            </div>

                            <table class="mt-2 table-compact table-bordered">
                                <tr>
                                    <th class="p-2 text-sm" style="width:20%;">Nama Pembimbing</th>
                                    <td class="p-2 text-sm"><a href="#"><?= $app->nama_pembimbing ?></a></td>
                                </tr>
                                <tr>
                                    <th class="p-2 text-sm" style="width:20%;">No Pembimbing</th>
                                    <td class="p-2 text-sm">
                                        <?php 
                                            $wa_hp = preg_replace('/[^0-9]/', '', $app->hp_pembimbing);
                                            if (strpos($wa_hp, '0') === 0) {
                                                $wa_hp = '62' . substr($wa_hp, 1);
                                            }
                                        ?>
                                        <a href="https://wa.me/<?= $wa_hp ?>" target="_blank" class="text-primary font-weight-bold"><i class="fab fa-whatsapp me-1"></i> <?= $app->hp_pembimbing ?></a>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="p-2 text-sm" style="width:20%;">Email Pembimbing</th>
                                    <td class="p-2 text-sm">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=<?= $app->email_pembimbing ?>" target="_blank" class="text-primary font-weight-bold"><i class="far fa-envelope me-1"></i> <?= $app->email_pembimbing ?></a>
                                    </td>
                                </tr>
                                <?php if ($app->nama_dosen) : ?>
                                <tr>
                                    <th class="p-2 text-sm bg-gray-100" style="width:20%;">Dosen Pembimbing</th>
                                    <td class="p-2 text-sm bg-gray-100"><span class="font-weight-bold"><?= $app->nama_dosen ?></span></td>
                                </tr>
                                <tr>
                                    <th class="p-2 text-sm bg-gray-100" style="width:20%;">No Dosen (WA)</th>
                                    <td class="p-2 text-sm bg-gray-100">
                                        <?php 
                                            $wa_dosen = preg_replace('/[^0-9]/', '', $app->hp_dosen);
                                            if (strpos($wa_dosen, '0') === 0) {
                                                $wa_dosen = '62' . substr($wa_dosen, 1);
                                            }
                                        ?>
                                        <a href="https://wa.me/<?= $wa_dosen ?>" target="_blank" class="text-info font-weight-bold"><i class="fab fa-whatsapp me-1"></i> <?= $app->hp_dosen ?></a>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="p-2 text-sm bg-gray-100" style="width:20%;">Email Dosen</th>
                                    <td class="p-2 text-sm bg-gray-100">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=<?= $app->email_dosen ?>" target="_blank" class="text-info font-weight-bold"><i class="far fa-envelope me-1"></i> <?= $app->email_dosen ?></a>
                                    </td>
                                </tr>
                                <?php endif ?>
                                <tr>
                                    <th class="p-2 text-sm" style="width:20%;">Laporan Akhir</th>
                                    <td class="p-2 text-sm">
                                        <?php if ($app->laporan) : ?>
                                            <a href="<?= base_url('assets/laporan/' . $app->laporan) ?>" target="_blank" class="badge badge-info border border-info px-3"><i class="fa fa-file-pdf me-1"></i> Lihat Laporan</a>
                                        <?php else : ?>
                                            <a href="/laporan-akhir" class="text-xs font-weight-bold text-dark"><i class="fa fa-external-link-alt me-1"></i> Pergi ke Menu Laporan</a>
                                        <?php endif ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach ?>
                </div>
            <?php endif ?>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>

<?= $this->section('bottomsc'); ?>
    <script src="/assets/js/plugins/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <?php if (in_groups('admin') || in_groups('pembimbing')) : ?>
        <script src="/assets/js/plugins/jquery.dataTables.min.js"></script>
        <script src="/assets/js/plugins/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#edit_dosen').select2({
                    dropdownParent: $('#modalEditApplication')
                });

                var tbApplication = $("#tbapplications").DataTable({
                    dom: '<"row"<"col-12"tr>><"row mt-2 px-3"<"col-12 col-md-6"i><"col-12 col-md-6"p>>',
                    pageLength: 10,
                    language: {
                        paginate: {
                            next: '<i class="fas fa-angle-right"></i>',
                            previous: '<i class="fas fa-angle-left"></i>'
                        }
                    },
                });
                
                // fil status
                $('#filstatus').on('change', function() {
                    $(this).val() == "" ? $(this).parent().removeClass('is-filled') : $(this).parent().addClass('is-filled');
                    tbApplication.columns(1).search(this.value).draw();
                });

                // fil jurusan
                $('#filjurusan').on('change', function() {
                    $(this).val() == "" ? $(this).parent().removeClass('is-filled') : $(this).parent().addClass('is-filled');
                    tbApplication.columns(3).search(this.value ? '^' + this.value + '$' : '', true, false).draw();
                });

                // fillaporan
                $('#fillaporan').on('change', function() {
                    $(this).val() == "" ? $(this).parent().removeClass('is-filled') : $(this).parent().addClass('is-filled');
                    if (this.value == 'lihat') {
                            tbApplication.columns(8).search('LIHAT').draw();
                    } else if (this.value == 'belum') {
                            tbApplication.columns(8).search('BELUM').draw();
                    } else {
                            tbApplication.columns(8).search('').draw();
                    }
                });

                // fil angkatan
                $('#filangkatan').on('change', function() {
                    $(this).val() == "" ? $(this).parent().removeClass('is-filled') : $(this).parent().addClass('is-filled');
                    tbApplication.columns(5).search(this.value).draw();
                });

                // fil search
                $('#filsearch').on('keyup', function() {
                    $(this).val() == "" ? $(this).parent().removeClass('is-filled') : $(this).parent().addClass('is-filled');
                    tbApplication.search(this.value).draw();
                });

                $("#tbapplications tbody").on('click', '.btn-destroy', function(s) {
                    const t = $(this).data('item');
                    const nama = $(this).parent().parent().find('td:eq(4)').text();
                    const instansi = $(this).parent().parent().find('td:eq(6) .iname').text();

                    Swal.fire({
                        icon: "warning",
                        title: "Hapus Data",
                        html: `Apakah anda yakin ingin menghapus data pendaftaran siswa <b>${nama}</b> di <b><i>${instansi}</i></b> ?`,
                        showCancelButton: !0,
                        confirmButtonText: "Ya, Hapus"
                    }).then(e => {
                        e.isConfirmed && $.ajax({
                            url: "/application/destroy/" + t,
                            type: "delete",
                            dataType: "json",
                            success: function(t) {
                                t.success ? Swal.fire({
                                    icon: "success",
                                    title: "Berhasil",
                                    text: t.message,
                                    showConfirmButton: !1,
                                    timer: 1500
                                }).then(t => {
                                    location.reload()
                                }) : Swal.fire({
                                    icon: "error",
                                    title: "Gagal",
                                    text: t.message,
                                    showConfirmButton: !0
                                }).then(t => {
                                    t.isConfirmed && location.reload()
                                })
                            }
                        })
                    })
                })

                $("#tbapplications tbody").on('click', '.btn-edit-status', function(s) {
                    const id = $(this).data('item');
                    const status = $(this).data('stts');
                    const id_dosen = $(this).data('dosen');
                    const nama = $(this).parent().parent().find('td:eq(4)').text();
                    const instansi = $(this).parent().parent().find('td:eq(6) .iname').text();

                    $('#edit_app_id').val(id);
                    $('#edit_status').val(status);
                    $('#edit_dosen').val(id_dosen).trigger('change');
                    
                    $('#modalEditApplication .modal-title').html(`Update Pendaftaran: <b>${nama}</b>`);
                    $('#modalEditApplication').modal('show');
                });

                $('#formEditApplication').on('submit', function(e) {
                    e.preventDefault();
                    const data = $(this).serialize();

                    $.ajax({
                        url: "/application/status/update",
                        type: "post",
                        dataType: "json",
                        data: data,
                        beforeSend: function() {
                            $('#formEditApplication button[type=submit]').attr('disabled', true).html('Simpan...');
                        },
                        success: function(res) {
                            if (res.success) {
                                Swal.fire({
                                    icon: "success",
                                    title: "Berhasil",
                                    text: res.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: "error",
                                    title: "Gagal",
                                    text: res.message,
                                    showConfirmButton: true
                                }).then(() => {
                                    $('#formEditApplication button[type=submit]').attr('disabled', false).html('Simpan');
                                });
                            }
                        },
                        error: function() {
                            Swal.fire("Error", "Terjadi kesalahan pada server", "error");
                            $('#formEditApplication button[type=submit]').attr('disabled', false).html('Simpan');
                        }
                    });
                });
            });
        </script>
    <?php endif ?>
<?= $this->endSection(); ?>