<?php
if (!function_exists('initCheck')) {
    function initCheck($uid, $tid)
    {
        $sid = getSidByUid($uid);
        
        // Robust fallback: if sid not found by uid, try finding from session or active user object
        if (!$sid && function_exists('user')) {
             $siswaModel = new \App\Models\SiswaModel();
             $sdata = $siswaModel->where('user_id', $uid)->first();
             $sid = $sdata ? $sdata->id : null;
        }
        
        if (!$sid) return false;

        $app = new \App\Models\ApplicationModel();
        $ready = null;

        $hasApplication = !empty(getApplicationSiswa($sid));
        $slotAvailable = getSlotAvailable($tid);
        $siswaActive = isSiswaActive($sid);
        
        $now = date('Y-m-d');
        $siswaModel = new \App\Models\SiswaModel();
        $siswa = $siswaModel->select('siswa.*, angkatan.tgl_mulai, angkatan.tgl_selesai')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', 'left')
            ->find($sid);

        $applyAllowed = ($siswa && $siswa->tgl_selesai) ? ($now <= $siswa->tgl_selesai) : $siswaActive;

        if (!$hasApplication && $slotAvailable > 0 && $applyAllowed) {
            $ready = true;
        } else {
            $ready = false;
        }

        return $ready;
    }
}

if (!function_exists('isEventFinished')) {
    function isEventFinished($uid)
    {
        $sid = getSidByUid($uid);
        $app = new \App\Models\ApplicationModel();
        $data = $app->where(['id_siswa' => $sid, 'status' => 'selesai'])->first();

        if ($data == null) {
            return false;
        } else {
            return true;
        }
    }
}

if (!function_exists('isSiswaActive')) {
    function isSiswaActive($sid)
    {
        $siswaModel = new \App\Models\SiswaModel();
        $angkatanModel = new \App\Models\AngkatanModel();
        
        $siswa = $siswaModel->select('siswa.*, angkatan.tgl_mulai, angkatan.tgl_selesai')
            ->join('angkatan', 'angkatan.id = siswa.angkatan', 'left')
            ->find($sid);

        if (!$siswa) {
            return false;
        }

        $now = date('Y-m-d');

        // If student has an angkatan assigned and it has dates, check them
        if ($siswa->tgl_mulai && $siswa->tgl_selesai) {
            return ($now >= $siswa->tgl_mulai && $now <= $siswa->tgl_selesai);
        }

        // Fallback: If no angkatan assigned, check if there's any active cohort globally
        $activeCohort = $angkatanModel->where('tgl_mulai <=', $now)
            ->where('tgl_selesai >=', $now)
            ->first();

        return ($activeCohort != null);
    }
}

if (!function_exists("checkNowAndPeroid")) {
    function checkNowAndPeroid()
    {
        $now = date('Y-m-d');
        $application = new \App\Models\ApplicationModel();
        $application_data = $application->select('lamaran.*, siswa.angkatan, siswa.laporan, angkatan.tahun, angkatan.nama as angkatan, angkatan.tgl_mulai, angkatan.tgl_selesai')
            ->join('siswa', 'siswa.id = lamaran.id_siswa')
            ->join('angkatan', 'angkatan.id = siswa.angkatan')
            ->findAll();

        foreach ($application_data as $ad) {
            if ($now > $ad->tgl_selesai && $ad->status == 'accepted' && $ad->laporan == null) {
                $application->update($ad->id, ['status' => 'unfinished']);
            }
        }
    }
}

if (!function_exists('getSiswaData')) {
    function getSiswaData($id)
    {
        $siswa = new \App\Models\SiswaModel();
        $data = $siswa->where('user_id', $id)->select('siswa.*, users.username, users.email as uemail, users.created_at')
            ->join('users', 'users.id = siswa.user_id')
            ->where('siswa.user_id', $id)->first();
        return $data;
    }
}

if (!function_exists('getPembimbingData')) {
    function getPembimbingData($id)
    {
        $db = \Config\Database::connect();
        $is_dosen = $db->table('auth_groups_users')
            ->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id')
            ->where(['user_id' => $id, 'name' => 'dosen_pembimbing'])
            ->countAllResults() > 0;

        if ($is_dosen) {
            $model = new \App\Models\DosenPembimbingModel();
            $table = 'dosen_pembimbing';
        } else {
            $model = new \App\Models\PembimbingModel();
            $table = 'pembimbing';
        }

        $data = $model->select($table . '.*, users.username, users.email as uemail, users.created_at')
            ->join('users', 'users.id = ' . $table . '.user_id')
            ->where($table . '.user_id', $id)->first();
        return $data;
    }
}


if (!function_exists('isLaporanUploaded')) {
    function isLaporanUploaded($sid)
    {
        $siswa = new \App\Models\SiswaModel();
        $data = $siswa->where('id', $sid)->first();
        if ($data->laporan == null) {
            return false;
        } else {
            return true;
        }
    }
}

if (!function_exists('getNamaInstansi')) {
    function getNamaInstansi($id_tempat)
    {
        $ins = new \App\Models\TempatModel();
        $data = $ins->find($id_tempat);
        return $data->nama;
    }
}

if (!function_exists('isVerifiedInstansi')) {
    function isVerifiedInstansi($id_tempat)
    {
        if ($id_tempat == null) {
            return '<i class="fas text-warning me-2 fa-info-circle" title="Tempat pengajuan sendiri (belum terverifikasi sekolah)" style="cursor:help;"></i>';
        } else {
            return '<i class="far text-success me-2 fa-check-circle" title="Tempat sudah terverifikasi sekolah" style="cursor:help;"></i>';
        }
    }
}


if (!function_exists('genBadgeRoles')) {
    function genBadgeRoles($r)
    {
        switch (strtolower($r)) {
            case 'admin':
                return '<span class="badge badge-success border border-success">Admin</span>';
                break;
            case 'pembimbing':
                return '<span class="badge badge-info border border-info">Pembimbing</span>';
                break;
            case 'siswa':
                return '<span class="badge badge-warning border border-warning">Siswa</span>';
                break;
            default:
                return '<span class="badge badge-secondary border border-secondary">Unknown</span>';
                break;
        }
    }
}


if (!function_exists('genBadgeStatusApplication')) {
    function genBadgeStatusApplication($s)
    {
        switch ($s) {
            case 'pending':
                return '<span class="badge badge-warning border border-warning">Pending</span>';
                break;
            case 'accepted':
                return '<span class="badge badge-success border border-success">Accepted</span>';
                break;
            case 'approved':
                return '<span class="badge badge-success border border-success">Approved</span>';
                break;
            case 'rejected':
                return '<span class="badge badge-danger border border-danger">Rejected</span>';
                break;
            case 'selesai':
                return '<span class="badge badge-info border border-info">Selesai</span>';
                break;
            case 'unfinish':
                return '<span class="badge badge-warning border border-warning">unfinish</span>';
                break;
            case 'reject by system':
                return '<span class="badge badge-danger border border-danger">reject by system</span>';
                break;
            default:
                return '<span class="badge badge-secondary border border-secondary">Unknown</span>';
                break;
        }
    }
}


if (!function_exists('genBadgeKehadiran')) {
    function genBadgeKehadiran($k)
    {
        switch ($k) {
            case 'hadir':
                return '<span class="badge badge-success border border-success">Hadir</span>';
                break;
            case 'izin':
                return '<span class="badge badge-warning border border-warning">Izin</span>';
                break;
            case 'sakit':
                return '<span class="badge badge-info border border-info">Sakit</span>';
                break;
            case 'alfa':
                return '<span class="badge badge-danger border border-danger">Alfa</span>';
                break;
            default:
                return '<span class="badge badge-secondary">Unknown</span>';
                break;
        }
    }
}

if (!function_exists('getSidByUid')) {
    function getSidByUid($uid)
    {
        $siswa = new \App\Models\SiswaModel();
        $data = $siswa->where('user_id', $uid)->first();
        return $data ? $data->id : null;
    }
}

if (!function_exists('getPidByUid')) {
    function getPidByUid($uid)
    {
        $pembimbing = new \App\Models\PembimbingModel();
        $data = $pembimbing->where('user_id', $uid)->first();
        return $data->id;
    }
}

if (!function_exists('getInstansiByPid')) {
    function getInstansiByPid($uid)
    {
        $ins = new \App\Models\TempatModel();
        $idp = getPidByUid($uid);

        $data = $ins->select('tempat_magang.*',)
            ->select('lamaran.id_tempat', 'lamaran.id_siswa', 'lamaran.status as status_lamaran')
            ->join('lamaran', 'lamaran.id_tempat = tempat_magang.id')
            ->where(['tempat_magang.pid' => $idp])
            ->whereIn('lamaran.status', ['accepted', 'selesai'])
            ->groupBy('tempat_magang.id')
            ->findAll();

        return $data;
    }
}

if (!function_exists('isAccepted')) {
    function isAccepted($sid)
    {
        $app = new \App\Models\ApplicationModel();
        $data = $app->where(['id_siswa' => $sid, 'status' => 'accepted'])
            ->orderBy('created_at', 'DESC')
            ->findAll();
        return $data;
    }
}

if (!function_exists('getApplicationSiswa')) {
    function getApplicationSiswa($sid)
    {
        $app = new \App\Models\ApplicationModel();
        $data = $app->where('id_siswa', $sid)
            ->whereIn('status', ['pending', 'accepted', 'selesai'])
            ->orderBy('created_at', 'DESC')
            ->findAll();
        return $data;
    }
}

if (!function_exists('getNimByUid')) {
    function getNimByUid()
    {
        $siswa = new \App\Models\SiswaModel();
        return $siswa->where('user_id', user_id())->first()->nim;
    }
}

if (!function_exists('getSlotAvailable')) {
    function getSlotAvailable($tid)
    {
        $app = new \App\Models\ApplicationModel();
        $tempatModel = new \App\Models\TempatModel();
        $angkatanModel = new \App\Models\AngkatanModel();
        $siswaModel = new \App\Models\SiswaModel();
        $now = date('Y-m-d');

        $activeCohort = $angkatanModel->where('tgl_mulai <=', $now)
            ->where('tgl_selesai >=', $now)
            ->first();

        $tempat = $tempatModel->find($tid);
        if (!$tempat) return 0;

        if (!$activeCohort) {
            // If no active cohort globally, just return the raw quota (or assume 0 available)
            // But usually, we want to know current accepted students.
            // Let's just find ALL accepted students for this place if no cohort period is defined.
            $count = $app->where('id_tempat', $tid)->where('status', 'accepted')->countAllResults();
            return max(0, $tempat->kuota - $count);
        }

        $aid = $activeCohort->id;
        
        $siswaIds = $siswaModel->select('id')->where('angkatan', $aid)->findAll();
        if (empty($siswaIds)) {
            return $tempat->kuota;
        }

        $idsArray = array_map(function($s) { return $s->id; }, $siswaIds);

        $count = $app->whereIn('id_siswa', $idsArray)
            ->where('id_tempat', $tid)
            ->where('status', 'accepted')
            ->countAllResults();

        return max(0, $tempat->kuota - $count);
    }
}

if (!function_exists('getStatusSiswa')) {
    function getStatusSiswa($sid)
    {
        if (!$sid) return 'not_applied';
        $app = new \App\Models\ApplicationModel();
        $data = $app->where(['id_siswa' => $sid])->first();
        return $data ? $data->status : 'not_applied';
    }
}

if (!function_exists('getLamaranSiswa')) {
    function getLamaranSiswa($uid, $status = null)
    {
        $sid = getSidByUid($uid);
        if (!$sid) return [];

        $app = new \App\Models\ApplicationModel();
        $query = $app->where(['id_siswa' => $sid]);
        if ($status) {
            $query->where('status', $status);
        }
        return $query->findAll();
    }
}

if (!function_exists('nilaiAvailable')) {
    function nilaiAvailable($sid)
    {
        $nilai = new \App\Models\NilaiModel();
        $data = $nilai->where(['ids' => $sid])->first();

        if ($data == null) {
            return false;
        } else {
            return true;
        }
    }
}

if (!function_exists('getNilaiSiswa')) {
    function getNilaiSiswa($sid)
    {
        $nilai = new \App\Models\NilaiModel();
        $data = $nilai->where(['ids' => $sid])->first();
        return $data;
    }
}
if (!function_exists('isSafetyCompleted')) {
    function isSafetyCompleted($uid)
    {
        $siswaModel = new \App\Models\SiswaModel();
        $siswa = $siswaModel->where('user_id', $uid)->first();
        if ($siswa) {
            return (bool)$siswa->is_safety_ready;
        }
        return false;
    }
}
